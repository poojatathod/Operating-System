#include<stdio.h>
#include<stdlib.h>

void main()
{
int i,j,temp[5],temp1;
int b[50]={100,500,200,300,600}
int p[50]={212,417,112,426}

for(i=0;i<4;i++)
{
for(j=0;j<5;j++)
{
temp[j]=b[j]-[i]
}
if(temp[j]>0 && min(temp[j]))
{

}

int min(temp[i])
{
for(i=0;i<5;i++)
{
if(arr[i]<arr[i+1])
{
temp1=arr[i];
arr[i]=temp1;
}




